package model;

public class SurveyDto {
	private int sur_num;
	private String sur_title;
	private String sur_startdate;
	private String sur_finishdate;
	private String sur_group;
	private String sur_position;
	private String sur_permit;
	
	
	
	public int getSur_num() {
		return sur_num;
	}
	public void setSur_num(int sur_num) {
		this.sur_num = sur_num;
	}
	public String getSur_title() {
		return sur_title;
	}
	public void setSur_title(String sur_title) {
		this.sur_title = sur_title;
	}
	public String getSur_startdate() {
		return sur_startdate;
	}
	public void setSur_startdate(String sur_startdate) {
		this.sur_startdate = sur_startdate;
	}
	public String getSur_finishdate() {
		return sur_finishdate;
	}
	public void setSur_finishdate(String sur_finishdate) {
		this.sur_finishdate = sur_finishdate;
	}
	public String getSur_group() {
		return sur_group;
	}
	public void setSur_group(String sur_group) {
		this.sur_group = sur_group;
	}
	public String getSur_position() {
		return sur_position;
	}
	public void setSur_position(String sur_position) {
		this.sur_position = sur_position;
	}
	public String getSur_permit() {
		return sur_permit;
	}
	public void setSur_permit(String sur_permit) {
		this.sur_permit = sur_permit;
	}
	
}
