package model;

public class EmpvacDto {
	private String department;
	private String name;
	private String vacationtype;
	private String startday;
	private String endday;
	private String starttime;
	private String endtime;
	private String numberofdays;
	private String currentTime;
	private String reason;
	
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getVacationtype() {
		return vacationtype;
	}
	public void setVacationtype(String vacationtype) {
		this.vacationtype = vacationtype;
	}
	public String getStartday() {
		return startday;
	}
	public void setStartday(String startday) {
		this.startday = startday;
	}
	public String getEndday() {
		return endday;
	}
	public void setEndday(String endday) {
		this.endday = endday;
	}
	public String getStarttime() {
		return starttime;
	}
	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}
	public String getEndtime() {
		return endtime;
	}
	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}
	public String getNumberofdays() {
		return numberofdays;
	}
	public void setNumberofdays(String numberofdays) {
		this.numberofdays = numberofdays;
	}
	public String getCurrentTime() {
		return currentTime;
	}
	public void setCurrentTime(String currentTime) {
		currentTime = currentTime;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
}
	
	
